use actix_web::{web, Responder, HttpResponse, Result};
use actix_web::http::header::{ContentDisposition, DispositionType};
use actix_files as fs;
use tera::{Tera, Context};
use crate::app::start;
use serde::{Deserialize};
use crate::ui::draw_chart;


pub(crate) async fn index(tera: web::Data<Tera>) -> impl Responder {
    let mut data = Context::new();
    data.insert("title", "Water Levels");
    let rendered = tera.render("index.html", &data).unwrap();
    HttpResponse::Ok().body(rendered)
}

#[derive(Debug, Deserialize)]
pub struct WaterLevel {
    rain_hours: String,
    landscapes: String,
}

pub(crate) async fn water_levels(tera: web::Data<Tera>, data: web::Form<WaterLevel>) -> impl Responder {
    println!("{:?}", data);
    let landscapes = data.landscapes.split_whitespace()
        .map(|x| x.parse::<f64>())
        .collect::<Result<Vec<f64>, _>>()
        .unwrap();
    let mut result = start(data.rain_hours.parse().unwrap(), landscapes);

    result = result.as_str().split_whitespace().collect();

    let res = result.split(',').map(|x| x.parse::<f32>())
        .collect::<Result<Vec<f32>, _>>()
        .unwrap();
    draw_chart(res);
    let mut data = Context::new();
    data.insert("title", "Water Levels");

    let path = "templates/water-level-chart.svg";
    let file = fs::NamedFile::open(path).unwrap();
    file
        .use_last_modified(true)
        .set_content_disposition(ContentDisposition {
            disposition: DispositionType::Inline,
            parameters: vec![],
        })
}