use crate::{handle, RAIN_DENSITY};
use anyhow::Result;

// Functions required to solve problem.
pub trait Landscape {
    type PointHeight: std::fmt::Debug + From<f64> + Clone;

    fn rain(
        &mut self,
        rain_distr: impl Fn(usize) -> Self::PointHeight,
        return_result: bool,
    ) -> Result<&[Self::PointHeight]>;

    fn rain_uniform(
        &mut self,
        cnt: Self::PointHeight,
        return_result: bool,
    ) -> Result<&[Self::PointHeight]> {
        self.rain(|_| cnt.clone(), return_result)
    }

    fn precision(&self) -> Self::PointHeight;
}

pub fn start(steps: usize, points: Vec<f64>) -> String {
    let mut stdout = String::new();
    let mut landscape = handle(points);
    for n in 1..=steps {
        match landscape.rain_uniform(RAIN_DENSITY.into(), true) {
            Ok(water_levels) => {
                stdout.push_str(
                    format!("{:?}", water_levels)
                        .trim_matches(&['[', ']'] as &[_]),
                );
            }
            Err(e) => {
                eprintln!("Error during {} st/th invocation of rain(): {}", n, e);
            }
        }
    }
    return stdout;
}
