use charts::{Chart, VerticalBarView, ScaleBand, ScaleLinear};

fn draw(input: &Vec<(&str,f32)>, landscapes: Vec<String>) {

    let width = 800;
    let height = 600;
    let (top, right, bottom, left) = (90, 40, 50, 60);

    let x = ScaleBand::new()
        .set_domain(landscapes)
        .set_range(vec![0, width - left - right])
        .set_inner_padding(0.0)
        .set_outer_padding(0.0);

    let y = ScaleLinear::new()
        .set_domain(vec![0_f32, input.len() as f32])
        .set_range(vec![height - top - bottom, 0]);

    let view = VerticalBarView::new()
        .set_x_scale(&x)
        .set_y_scale(&y)
        .load_data(&input).unwrap();

    // Generate and save the chart.
    Chart::new()
        .set_width(width)
        .set_height(height)
        .set_margins(top, right, bottom, left)
        .add_title(String::from("Water Levels"))
        .add_view(&view)
        .add_axis_bottom(&x)
        .add_axis_left(&y)
        .add_left_axis_label("Water Level")
        .add_bottom_axis_label("Landscapes")
        .save("./templates/water-level-chart.svg").unwrap();
}

pub fn draw_chart(data : Vec<f32>) {
    let mut x = vec![String::new();0];
    for i in 1 ..= data.len() {
        x.push(i.to_string())
    }

    let mut v = vec![("", 0.0 as f32); 0];

    for i in 0.. data.len() {
        let n = data[i].clone();
        v.push((x[i].as_str().clone(), n));
    }

    draw(&v.clone(), x.clone());
}

#[test]
fn entry_point() {
    let data = [1.0, 2.0, 3.0];
    let mut x = vec![String::new();0];
    for i in 0 ..data.len() {
        x.push(i.to_string())
    }

    let mut v = vec![("", 0.0 as f32); 0];

    for i in 0.. data.len() {
        let n = data[i].clone();
        v.push((x[i].as_str().clone(), n));
    }

    println!("{:?},{:?},{:?}", data,x, v);

    draw(&v.clone(), x.clone());
}