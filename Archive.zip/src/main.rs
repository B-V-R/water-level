use tera::{Tera};
use crate::app::Landscape;
use actix_web::{App, HttpServer, web};
use actix_web::web::Data;

// Amount of rain that falls onto one point (segment) in one step (1h).
const RAIN_DENSITY: f64 = 1.0;

mod app;
mod rain_landscapes;
mod util;
mod ui;

fn handle(points_heights: Vec<f64>) -> impl Landscape {
    rain_landscapes::Landscape::create(points_heights)
}

// Program main function.
#[actix_web::main]
async fn main() -> std::io::Result<()> {

    HttpServer::new(|| {
        let tera = Tera::new("templates/**/*").unwrap();
        App::new()
            .app_data(Data::new(tera))
            .service(web::resource("/")
                         .route(web::get().to(util::index)),
            )
            .service(web::resource("/waterlevel")
                         .route(web::post().to(util::water_levels)),
            )
    })
        .bind("0.0.0.0:8080")?
        .run()
        .await
}


